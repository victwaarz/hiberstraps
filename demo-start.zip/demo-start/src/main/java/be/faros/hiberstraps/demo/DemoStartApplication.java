package be.faros.hiberstraps.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoStartApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoStartApplication.class, args);
	}

}
