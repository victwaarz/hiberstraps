## Satellite starter
This is the start point for exercise 2 of the Hibernate course.
It was created using [Spring Initializr](http://start.spring.io).

Included dependencies are Spring Data JPA, Spring Web, Bean Validation and the H2 Database driver.